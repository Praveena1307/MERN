import logo from './logo.svg';
import './App.css';
import TodoApp from './To-Do';

function App() {
  return (
    <div className="App">
      <TodoApp/>
    </div>
  );
}

export default App;
